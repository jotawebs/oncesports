const PRODUCTS = [
  { id: 'nutrex-creatine', brand: 'Nutrex', name: 'Creatine Monohydrate', category: 'Creatinas', spec: '1000 g · 200 servicios', divisa: 49.99, bcv: 70, code: 'N', available: true },
  { id: 'muscletech-celltech', brand: 'MuscleTech', name: 'Cell-Tech HCl+', category: 'Creatinas', spec: '120 servicios', divisa: 39.99, bcv: 49.99, code: 'M', available: true },
  { id: 'on-creatine', brand: 'Optimum Nutrition', name: 'Micronized Creatine', category: 'Creatinas', spec: '300 g · 60 servicios', divisa: 29.99, bcv: 39.99, code: 'O', available: true },
  { id: 'allmax-creatine', brand: 'Allmax', name: 'Creatine', category: 'Creatinas', spec: '400 g · 80 servicios', divisa: 35, bcv: 45, code: 'A', available: true },
  { id: 'rule-one-creatine', brand: 'Rule One', name: 'Creatine', category: 'Creatinas', spec: '30 servicios', divisa: null, bcv: null, code: 'R', available: false },
  { id: 'rule-one-amino', brand: 'Rule One', name: 'Aminoácidos + BCAA', category: 'Aminoácidos y BCAA', spec: 'Presentación por confirmar', divisa: null, bcv: null, code: 'R1', available: false },
  { id: 'nutrex-amino', brand: 'Nutrex', name: 'Aminoácidos + BCAA', category: 'Aminoácidos y BCAA', spec: 'Presentación por confirmar', divisa: null, bcv: null, code: 'N', available: false },
  { id: 'allmax-bcaa', brand: 'Allmax', name: 'Aminoácidos + BCAA', category: 'Aminoácidos y BCAA', spec: 'Presentación por confirmar', divisa: null, bcv: null, code: 'A', available: false },
  { id: 'eaa', brand: 'Once Sports', name: 'EAA', category: 'Aminoácidos y BCAA', spec: 'Presentación por confirmar', divisa: null, bcv: null, code: 'E', available: false },
  { id: 'glutamine', brand: 'Once Sports', name: 'Glutamina', category: 'Proteínas y otros', spec: 'Presentación por confirmar', divisa: null, bcv: null, code: 'G', available: false },
  { id: 'arginine', brand: 'Once Sports', name: 'Arginina HCl', category: 'Proteínas y otros', spec: 'Presentación por confirmar', divisa: null, bcv: null, code: 'A', available: false },
  { id: 'beta-alanine', brand: 'Once Sports', name: 'Beta Alanina', category: 'Proteínas y otros', spec: 'Presentación por confirmar', divisa: null, bcv: null, code: 'B', available: false },
  { id: 'leucine', brand: 'Once Sports', name: 'Leucina', category: 'Proteínas y otros', spec: 'Presentación por confirmar', divisa: null, bcv: null, code: 'L', available: false },
  { id: 'collagen', brand: 'Once Sports', name: 'Péptidos de colágeno', category: 'Proteínas y otros', spec: 'Presentación por confirmar', divisa: null, bcv: null, code: 'C', available: false }
];

const CART_KEY = 'once-sports-cart-v1';
const ZONE_KEY = 'once-sports-zone-v1';
let cart = loadJson(CART_KEY, {});
let activeCategory = 'all';
let query = '';

const $ = (selector) => document.querySelector(selector);
const money = (value) => value == null ? 'Por confirmar' : `$${value.toFixed(2)}`;
const normalize = (value) => value.toLocaleLowerCase('es').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
function loadJson(key, fallback) { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } }
function saveState() { localStorage.setItem(CART_KEY, JSON.stringify(cart)); localStorage.setItem(ZONE_KEY, $('#delivery-zone')?.value || ''); }
function getProduct(id) { return PRODUCTS.find((product) => product.id === id); }
function categories() { return ['all', ...new Set(PRODUCTS.map((product) => product.category))]; }
function formatCategory(category) { return category === 'all' ? 'Todos' : category; }

function setupFilters() {
  $('#category-filters').innerHTML = categories().map((category) => `<button class="filter-button ${category === activeCategory ? 'active' : ''}" type="button" data-category="${category}">${formatCategory(category)}</button>`).join('');
  $('#category-filters').addEventListener('click', (event) => {
    const button = event.target.closest('[data-category]');
    if (!button) return;
    activeCategory = button.dataset.category;
    document.querySelectorAll('.filter-button').forEach((item) => item.classList.toggle('active', item === button));
    renderProducts();
  });
  const brands = [...new Set(PRODUCTS.map((product) => product.brand))].sort((a, b) => a.localeCompare(b));
  $('#brand-filter').insertAdjacentHTML('beforeend', brands.map((brand) => `<option value="${brand}">${brand}</option>`).join(''));
}

function filteredProducts() {
  const selectedBrand = $('#brand-filter').value;
  return PRODUCTS.filter((product) => {
    const text = normalize(`${product.name} ${product.brand} ${product.category}`);
    return (activeCategory === 'all' || product.category === activeCategory) && (selectedBrand === 'all' || product.brand === selectedBrand) && (!query || text.includes(normalize(query)));
  });
}

function renderProducts() {
  const products = filteredProducts();
  $('#result-count').textContent = `${products.length} ${products.length === 1 ? 'producto' : 'productos'} seleccionados`;
  $('#empty-state').hidden = products.length > 0;
  $('#product-grid').innerHTML = products.map((product) => `
    <article class="product-card">
      <div class="product-visual ${product.available ? '' : 'pending'}">
        <div class="product-ghost">${product.code}<small>Once Sports</small></div>
        <span class="fallback-label">${product.available ? 'Foto pendiente de catálogo' : 'Datos por confirmar'}</span>
      </div>
      <div class="product-card-body">
        <div class="product-brand">${product.brand}</div>
        <h3>${product.name}</h3>
        <div class="product-spec">${product.spec}</div>
        <div class="price-block">
          <div class="price ${product.divisa == null ? 'pending' : ''}"><label>Divisa</label><strong>${money(product.divisa)}</strong></div>
          <div class="price ${product.bcv == null ? 'pending' : ''}"><label>Dólar BCV</label><strong>${product.bcv == null ? 'Por confirmar' : money(product.bcv)}</strong></div>
        </div>
        <button class="add-button" type="button" data-add="${product.id}">${product.available ? 'Agregar al pedido ↗' : 'Consultar por WhatsApp ↗'}</button>
      </div>
    </article>
  `).join('');
  $('#product-grid').querySelectorAll('[data-add]').forEach((button) => button.addEventListener('click', () => addToCart(button.dataset.add)));
}

function addToCart(id) {
  const product = getProduct(id);
  if (!product) return;
  cart[id] = (cart[id] || 0) + 1;
  saveState();
  renderCart();
  openCart();
  showToast(`${product.name} agregado al pedido`);
}

function cartEntries() { return Object.entries(cart).map(([id, qty]) => ({ product: getProduct(id), qty })).filter((entry) => entry.product && entry.qty > 0); }
function renderCart() {
  const entries = cartEntries();
  const count = entries.reduce((sum, entry) => sum + entry.qty, 0);
  $('#cart-count').textContent = count;
  $('#cart-count-title').textContent = `(${count})`;
  if (!entries.length) {
    $('#cart-items').innerHTML = '<div class="cart-empty"><span class="cart-empty-mark">＋</span><p>Tu pedido está vacío.</p><small>Agrega productos del catálogo para comenzar.</small></div>';
  } else {
    $('#cart-items').innerHTML = entries.map(({ product, qty }) => `
      <div class="cart-line">
        <div class="cart-line-visual">${product.code}</div>
        <div><h3>${product.name}</h3><p>${product.brand} · ${product.spec}</p><div class="qty-control"><button type="button" data-decrease="${product.id}" aria-label="Restar una unidad">−</button><span>${qty}</span><button type="button" data-increase="${product.id}" aria-label="Sumar una unidad">＋</button></div><button class="remove-line" type="button" data-remove="${product.id}">Eliminar</button></div>
        <div class="cart-line-price"><strong>${product.divisa == null ? '—' : money(product.divisa * qty)}</strong></div>
      </div>
    `).join('');
    $('#cart-items').querySelectorAll('[data-increase]').forEach((button) => button.addEventListener('click', () => updateQty(button.dataset.increase, 1)));
    $('#cart-items').querySelectorAll('[data-decrease]').forEach((button) => button.addEventListener('click', () => updateQty(button.dataset.decrease, -1)));
    $('#cart-items').querySelectorAll('[data-remove]').forEach((button) => button.addEventListener('click', () => removeFromCart(button.dataset.remove)));
  }
  const totalDivisa = entries.reduce((sum, { product, qty }) => sum + (product.divisa || 0) * qty, 0);
  const totalBcv = entries.reduce((sum, { product, qty }) => sum + (product.bcv || 0) * qty, 0);
  $('#total-divisa').textContent = money(totalDivisa);
  $('#total-bcv').textContent = totalBcv ? `${money(totalBcv)} BCV` : 'BCV por confirmar';
}
function updateQty(id, delta) { cart[id] = (cart[id] || 0) + delta; if (cart[id] <= 0) delete cart[id]; saveState(); renderCart(); }
function removeFromCart(id) { delete cart[id]; saveState(); renderCart(); }
function openCart() { $('#cart-overlay').hidden = false; requestAnimationFrame(() => $('#cart-panel').classList.add('open')); $('#cart-panel').setAttribute('aria-hidden', 'false'); document.body.style.overflow = 'hidden'; }
function closeCart() { $('#cart-panel').classList.remove('open'); $('#cart-panel').setAttribute('aria-hidden', 'true'); document.body.style.overflow = ''; setTimeout(() => { $('#cart-overlay').hidden = true; }, 300); }
function showToast(message) { const toast = $('#toast'); toast.textContent = message; toast.classList.add('show'); clearTimeout(showToast.timeout); showToast.timeout = setTimeout(() => toast.classList.remove('show'), 2200); }

function sendToWhatsApp() {
  const entries = cartEntries();
  if (!entries.length) { showToast('Agrega al menos un producto'); return; }
  const zone = $('#delivery-zone').value.trim();
  if (!zone) { $('#delivery-zone').focus(); showToast('Indica tu zona o dirección de entrega'); return; }
  const lines = entries.map(({ product, qty }) => `• ${qty} x ${product.brand} ${product.name} (${product.spec})`);
  const totalDivisa = entries.reduce((sum, { product, qty }) => sum + (product.divisa || 0) * qty, 0);
  const totalBcv = entries.reduce((sum, { product, qty }) => sum + (product.bcv || 0) * qty, 0);
  const text = ['¡Hola Once Sports! Quiero preparar este pedido:', '', ...lines, '', `Total estimado Divisa: ${money(totalDivisa)}`, `Total estimado Dólar BCV: ${totalBcv ? money(totalBcv) : 'Por confirmar'}`, `Zona o dirección: ${zone}`, '', 'Quedo atento/a para confirmar disponibilidad y delivery.'].join('\n');
  window.open(`https://wa.me/584223581111?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
}

function init() {
  setupFilters();
  $('#search').addEventListener('input', (event) => { query = event.target.value; renderProducts(); });
  $('#brand-filter').addEventListener('change', renderProducts);
  $('#open-cart').addEventListener('click', openCart);
  $('#close-cart').addEventListener('click', closeCart);
  $('#cart-overlay').addEventListener('click', closeCart);
  $('#send-whatsapp').addEventListener('click', sendToWhatsApp);
  $('#delivery-zone').value = localStorage.getItem(ZONE_KEY) || '';
  $('#delivery-zone').addEventListener('input', saveState);
  renderProducts();
  renderCart();
}

document.addEventListener('DOMContentLoaded', init);
